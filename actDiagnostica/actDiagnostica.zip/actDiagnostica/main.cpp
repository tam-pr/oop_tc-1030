//A01648580 Tam Padilla
//github tam-pr
//github repo: https://github.com/tam-pr/oop_tc-1030

#include "adminHotel.h"

int main(){

    Hotel hotel1; 
    
    Room room1; 
        room1.checkIn();
    
    hotel1.displaySummary(); 

    room1.checkOut(); 

    return 0; 
}; 